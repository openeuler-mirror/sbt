package test3

trait A
