package test.nested

trait Foo {
	def xyz(x: test.Nested)
}
