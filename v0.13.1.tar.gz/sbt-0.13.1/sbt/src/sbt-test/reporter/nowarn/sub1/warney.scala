object warney {
	def foo = {
    0
  	0
	}
}
