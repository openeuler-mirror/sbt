

public class JavaTest {
	public static final int X = 9;
}