object B {
  val x = 3
}
