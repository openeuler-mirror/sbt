package a.b

class ScalaA
{
	def increment(i: Int) = i + 1
}