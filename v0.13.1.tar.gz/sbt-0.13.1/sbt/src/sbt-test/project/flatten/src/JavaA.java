public class JavaA
{
	public int inc(int i) { return i+1; }
}