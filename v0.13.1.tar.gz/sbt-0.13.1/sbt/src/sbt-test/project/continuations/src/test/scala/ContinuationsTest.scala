import org.junit._
import Assert._

class ContinuationsTest
{
	@Test
	def basic
	{
		assertTrue(Example.x == 20)
	}
}