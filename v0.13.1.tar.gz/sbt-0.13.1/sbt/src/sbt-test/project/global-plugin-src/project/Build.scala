import sbt._

object Test {
  assert(test.Global.x == 3);
}
