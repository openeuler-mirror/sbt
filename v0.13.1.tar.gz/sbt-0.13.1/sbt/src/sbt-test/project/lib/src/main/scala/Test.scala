package injar

object Test
{
	def foo: Option[String] = None
}