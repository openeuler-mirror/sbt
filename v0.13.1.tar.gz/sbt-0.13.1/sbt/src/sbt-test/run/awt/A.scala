object O {
  def main(argv: Array[String]) {
    new java.awt.Color(0,0,0)
  }
}
