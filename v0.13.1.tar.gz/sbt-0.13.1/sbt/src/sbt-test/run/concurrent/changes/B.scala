import java.io.File

object B {
	def main(args: Array[String]) {
		Thread.sleep(1000)
	}
}