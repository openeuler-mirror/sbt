object Spawn
{
	def main(args: Array[String]) {}
}