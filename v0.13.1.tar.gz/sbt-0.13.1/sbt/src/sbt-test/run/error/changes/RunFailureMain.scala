object Spawn
{
	def main(args: Array[String])
	{
		error("Test error main")
	}
}