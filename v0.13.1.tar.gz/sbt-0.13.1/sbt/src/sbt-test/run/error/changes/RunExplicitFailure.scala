object Spawn
{
	def main(args: Array[String]) { System.exit(1); }
}