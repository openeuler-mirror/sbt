package test;

public class Outer {
	public class Inner extends Outer {
		public class InnerB extends Outer {}
	}
}
