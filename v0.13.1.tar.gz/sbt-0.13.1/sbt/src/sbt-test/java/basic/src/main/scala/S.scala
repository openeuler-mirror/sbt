package stest

class S
{
	val x = test.R.y
	val y = 5
}