package test;

import java.util.ArrayList;
import java.util.List;

public final class R {
   public static final int y = 4;
   private static List<String> z = new ArrayList<String>();
}
