package test;

public class Fail {