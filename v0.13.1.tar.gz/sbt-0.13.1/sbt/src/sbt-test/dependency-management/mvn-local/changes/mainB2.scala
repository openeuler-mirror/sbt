import org.junit.Test

object B { val y = A.x }
