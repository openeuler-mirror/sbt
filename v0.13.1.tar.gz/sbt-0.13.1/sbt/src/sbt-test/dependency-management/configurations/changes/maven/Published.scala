object PublishedMaven
{
	val x = 3
}