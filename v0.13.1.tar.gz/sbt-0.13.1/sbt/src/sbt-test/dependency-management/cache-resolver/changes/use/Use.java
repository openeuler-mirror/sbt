public final class Use {
	public static final int x = Def.x;
}
