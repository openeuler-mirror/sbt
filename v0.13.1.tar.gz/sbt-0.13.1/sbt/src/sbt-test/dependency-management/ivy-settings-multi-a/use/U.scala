import junit._

object U {
	val x = D.x
}
