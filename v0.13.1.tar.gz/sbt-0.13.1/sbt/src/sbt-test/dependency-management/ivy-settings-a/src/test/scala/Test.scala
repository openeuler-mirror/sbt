import org.scalacheck._

object Test extends Properties("Test")