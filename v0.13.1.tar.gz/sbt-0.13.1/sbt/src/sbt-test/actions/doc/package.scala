package pkg

package object foo {
  final val foo = "Foo"
}
