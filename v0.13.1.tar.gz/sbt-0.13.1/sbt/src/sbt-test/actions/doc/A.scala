object A {
	/**
	* @param i An argument
	*/
	def x(i: Int) = 3
}