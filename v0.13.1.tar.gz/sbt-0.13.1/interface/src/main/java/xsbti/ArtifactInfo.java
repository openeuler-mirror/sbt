package xsbti;

public final class ArtifactInfo
{
	public static final String ScalaOrganization = "org.scala-lang";
	public static final String ScalaLibraryID = "scala-library";
	public static final String ScalaCompilerID = "scala-compiler";
	public static final String SbtOrganization = "org.scala-sbt";
}