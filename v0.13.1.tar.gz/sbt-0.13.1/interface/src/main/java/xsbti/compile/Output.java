package xsbti.compile;
/** Abstract interface denoting the output of the compilation. Inheritors are SingleOutput with a global output directory and
 * MultipleOutput that specifies the output directory per source file.
 */
public interface Output
{
}
