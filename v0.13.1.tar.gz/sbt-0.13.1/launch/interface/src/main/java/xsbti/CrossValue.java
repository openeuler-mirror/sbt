package xsbti;

public enum CrossValue
{
	Disabled, Full, Binary;
}
